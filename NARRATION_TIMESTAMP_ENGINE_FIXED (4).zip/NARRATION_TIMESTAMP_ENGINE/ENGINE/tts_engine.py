import asyncio
from pathlib import Path


async def generate_narration(text, output_path: Path, cfg):
    provider = cfg.get("provider", "edge_tts")

    if provider != "edge_tts":
        raise ValueError(
            f"Unsupported TTS provider: {provider}. "
            "Current engine supports edge_tts."
        )

    try:
        import edge_tts
    except ImportError:
        raise RuntimeError(
            "edge-tts is not installed. Run INSTALL.bat"
        )

    voice = cfg.get("voice", "en-US-GuyNeural")
    rate = cfg.get("rate", "+0%")
    pitch = cfg.get("pitch", "+0Hz")

    communicate = edge_tts.Communicate(
        text=text,
        voice=voice,
        rate=rate,
        pitch=pitch
    )
    await communicate.save(str(output_path))
