import json
from pathlib import Path


def validate(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))

    problems = []

    previous_end = -1.0
    for item in data.get("words", []):
        if item["start"] < previous_end:
            problems.append(
                f"Word overlap near {item['word']}: "
                f"{item['start']} < {previous_end}"
            )
        if item["end"] < item["start"]:
            problems.append(
                f"Invalid word timing: {item['word']}"
            )
        previous_end = item["end"]

    if problems:
        print("VALIDATION FAILED")
        for p in problems:
            print("-", p)
        return False

    print("TIMELINE VALID")
    print("Duration:", data["duration"])
    print("Words:", len(data.get("words", [])))
    print("Sentences:", len(data.get("sentences", [])))
    return True


if __name__ == "__main__":
    import sys
    validate(sys.argv[1])
