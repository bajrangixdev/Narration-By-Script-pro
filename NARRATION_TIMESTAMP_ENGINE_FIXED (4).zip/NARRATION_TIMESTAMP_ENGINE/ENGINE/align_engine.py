from pathlib import Path


def align_audio(audio_path, cfg, original_script, output_cfg):
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise RuntimeError(
            "faster-whisper is not installed. Run INSTALL.bat"
        )

    model_name = cfg.get("model", "small")
    device = cfg.get("device", "cpu")
    compute_type = cfg.get("compute_type", "int8")
    language = cfg.get("language") or None

    print(
        f"[ALIGN] model={model_name} device={device} "
        f"compute_type={compute_type}"
    )

    model = WhisperModel(
        model_name,
        device=device,
        compute_type=compute_type
    )

    # VAD uses a separate Silero ONNX model. On some Windows/Python setups it
    # can fail with ONNXRuntime "bad allocation". Default to VAD disabled and
    # retry without VAD if it was explicitly enabled in config.
    use_vad = bool(cfg.get("vad_filter", False))
    try:
        segments, info = model.transcribe(
            str(audio_path),
            language=language,
            word_timestamps=cfg.get("word_timestamps", True),
            vad_filter=use_vad
        )
        # faster-whisper returns a lazy segment generator, so errors can occur
        # while iterating; fallback is handled below by materializing safely.
        segments = list(segments)
    except Exception as exc:
        message = str(exc).lower()
        if use_vad and ("bad allocation" in message or "onnxruntime" in message or "runtime_exception" in message):
            print("[ALIGN] VAD failed in ONNXRuntime; retrying with vad_filter=False...")
            segments, info = model.transcribe(
                str(audio_path),
                language=language,
                word_timestamps=cfg.get("word_timestamps", True),
                vad_filter=False
            )
            segments = list(segments)
        else:
            raise


    words = []
    sentences = []

    for seg in segments:
        seg_words = []

        for w in (seg.words or []):
            item = {
                "word": w.word.strip(),
                "start": round(float(w.start), 3),
                "end": round(float(w.end), 3)
            }
            if item["word"]:
                words.append(item)
                seg_words.append(item)

        text = seg.text.strip()

        if text:
            sentences.append({
                "id": len(sentences) + 1,
                "start": round(float(seg.start), 3),
                "end": round(float(seg.end), 3),
                "duration": round(float(seg.end - seg.start), 3),
                "text": text
            })

    duration = 0.0
    if sentences:
        duration = max(s["end"] for s in sentences)
    elif words:
        duration = max(w["end"] for w in words)

    return {
        "language": getattr(info, "language", language),
        "language_probability": getattr(info, "language_probability", None),
        "duration": duration,
        "words": words,
        "sentences": sentences
    }
