import json
from pathlib import Path


def write_timestamp_json(path: Path, audio_path: Path, result, cfg):
    digits = int(cfg["output"].get("round_digits", 3))

    data = {
        "format": "narration_timestamp_v1",
        "audio_file": audio_path.name,
        "duration": round(result["duration"], digits),
        "language": result.get("language"),
        "language_probability": result.get("language_probability"),
        "sentences": result["sentences"] if cfg["output"].get(
            "include_sentences", True
        ) else [],
        "words": result["words"] if cfg["output"].get(
            "include_words", True
        ) else []
    }

    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )
