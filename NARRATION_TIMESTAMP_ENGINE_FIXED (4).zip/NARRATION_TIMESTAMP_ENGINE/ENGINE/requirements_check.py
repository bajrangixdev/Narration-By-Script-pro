import importlib.util

packages = ["edge_tts", "faster_whisper"]

for package in packages:
    ok = importlib.util.find_spec(package) is not None
    print(f"{package}: {'OK' if ok else 'MISSING'}")
