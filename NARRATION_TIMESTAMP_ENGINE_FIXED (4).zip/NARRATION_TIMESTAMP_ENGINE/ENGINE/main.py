from pathlib import Path
import json
import sys
import asyncio
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "ENGINE"))

from tts_engine import generate_narration
from align_engine import align_audio
from json_writer import write_timestamp_json


def load_config():
    with open(ROOT / "CONFIG" / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)


def log(msg):
    print(f"[ENGINE] {msg}")


def main():
    cfg = load_config()

    script_path = ROOT / cfg["input_script"]
    audio_path = ROOT / cfg["output_audio"]
    timestamp_path = ROOT / cfg["output_timestamps"]

    if not script_path.exists():
        raise FileNotFoundError(f"Script not found: {script_path}")

    script = script_path.read_text(encoding="utf-8").strip()
    if not script:
        raise ValueError("INPUT/script.txt is empty.")

    audio_path.parent.mkdir(parents=True, exist_ok=True)
    timestamp_path.parent.mkdir(parents=True, exist_ok=True)

    log("1/3 Generating narration...")
    asyncio.run(generate_narration(
        script,
        audio_path,
        cfg["tts"]
    ))

    log(f"Narration created: {audio_path}")

    log("2/3 Aligning narration to actual audio...")
    result = align_audio(
        audio_path,
        cfg["alignment"],
        script,
        cfg["output"]
    )

    log("3/3 Writing exact timestamp JSON...")
    write_timestamp_json(
        timestamp_path,
        audio_path,
        result,
        cfg
    )

    print()
    print("============================================")
    print(" COMPLETE")
    print("============================================")
    print(f"Audio:      {audio_path}")
    print(f"Timestamps: {timestamp_path}")
    print(f"Duration:   {result['duration']:.3f} sec")
    print(f"Words:      {len(result['words'])}")
    print(f"Sentences:  {len(result['sentences'])}")
    print("============================================")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print()
        print("[ERROR]", str(e))
        print()
        print("Check LOGS and README.md.")
        raise
